function openLogin() {
    window.location.replace("login.html");
}
