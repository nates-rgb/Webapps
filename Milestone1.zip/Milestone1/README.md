This is where we will work oine milestone one, once doen copy files into milestone 2 for next steps.



To Run this Start index.html that is the home page.
